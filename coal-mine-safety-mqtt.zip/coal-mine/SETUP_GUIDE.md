# Coal Mine Safety Prototype – MQTT Upgrade: Setup Guide (Windows)

> **Everything in this prototype uses SIMULATED data.** It is a learning/demo project. It is **not** a certified gas-monitoring, alarm or safety-control system and must not be used for real mine safety decisions without validated hardware, applicable regulatory review and professional safety engineering.

## 0. What I inspected, and what I could not

| File you uploaded | Result |
|---|---|
| `Coal-Mine-Safety-Workflow-Groq.json` | Read fully (17 nodes, see below). |
| `frontend.zip` (second upload) | Read fully: Vite + React 18 + axios, dark CSS-variable theme. `src/api.js` POSTs the manual form to `VITE_N8N_WEBHOOK_URL` (`http://localhost:5173` dev server) and reads the synchronous reply; `App.jsx` shows `SafetyResult` and `AgentAnalysis`. The first upload of `frontend` was empty. |

**Your original workflow (unchanged on disk):** `Webhook - Mine Safety Intake` (POST `/mine-safety`, respond-to-webhook mode) → `Validate & Normalize Input` → `Input Valid?` → `Build Safety Agent Request` → `Safety Analysis Agent (Groq)` (HTTP Request, model `openai/gpt-oss-20b`, credential ref `Groq API Key (Header Auth)`) → `Parse Safety Agent Output` → `Safety Agent Parsed OK?` → `Build Coordinator Agent Request` → `Coordinator Agent (Groq)` → `Parse Coordinator Output` → `Coordinator Parsed OK?` → `Route by Status` (Switch) → `Tag Priority - SAFE/WARNING/DANGER` → `Respond - Analysis Result`. Errors go to `Respond - Error` (HTTP 422). So your dashboard currently **POSTs manual form data and reads the synchronous response**. MQTT has no caller waiting for a response, which is why a relay backend is needed (section 2).

## 1. Files delivered

| File | Purpose |
|---|---|
| `sensor_simulator.py` | Simulated sensor publisher (paho-mqtt). |
| `Coal-Mine-Safety-Workflow-Groq-MQTT.json` | **New separate file**; your original is untouched. |
| `dashboard-backend/server.js`, `package.json` | Zero-dependency relay: n8n → backend → React (SSE). |
| `frontend-updated/` | Overlay for your Vite project: new `LiveMinePanel` + `useMineStream`, edited `App.jsx`, `api.js`, `.env.example`. |
| `THRESHOLDS_AND_TESTS.md` | Thresholds, sources, conflict resolution, test checklist. |

## 2. Architecture and why a backend is needed

```
sensor_simulator.py --MQTT--> Mosquitto (localhost:1883) --> n8n MQTT Trigger
   --> Validate & Normalize --> Local Rule Check --+--> (immediately) POST rule alert --> relay backend
                                                    +--> Safety Analysis Agent (Groq) --> Coordinator Agent (Groq)
                                                         --> Enforce Rule Floor --> Route/Tag --> POST result --> relay backend
relay backend (http://localhost:3001) --SSE--> React dashboard
```
A browser cannot subscribe to what n8n computes after an MQTT message. So n8n pushes each event with an HTTP Request node to `dashboard-backend` (plain Node, no `npm install` needed), and React listens with Server-Sent Events (auto-reconnect, polling fallback). The original webhook still works for manual input.

## 3. What changed in the workflow (every node)

**New nodes**
| Node | What it does |
|---|---|
| `MQTT Trigger - Sensor Readings` | Subscribes to `mine/+/sensors` (matches `mine/zone1/sensors`, `mine/zone2/sensors`, …). "JSON Parse Body" is on; if parsing fails the raw string is passed on and rejected by validation. Credential placeholder `MQTT_CREDENTIAL_ID`. |
| `Local Rule Check` | Deterministic thresholds (no AI) → `ruleCheck {status, critical, triggered[], notes}`. Missing values are skipped, never invented. |
| `Build Rule Alert Event` → `Push to Dashboard Backend` | Sends reading + rule status to the dashboard **before** any AI call, so a critical reading appears without waiting for Groq. This branch is connected first/top so n8n runs it first. |
| `Enforce Rule Floor & Build Result` | `finalStatus = max(ruleStatus, aiStatus)`; merges rule + AI hazards; adds rule-based baseline actions; records `statusResolution`. |
| `Webhook Request? (result)` / `(error)` | Only answer with `Respond to Webhook` if the run came from the webhook; MQTT runs skip it. |
| `Build Error Event` | Reports rejected messages / AI failures to the dashboard. |

**Modified nodes** (everything else, including connections, Switch and Tag nodes, is preserved)
- `Validate & Normalize Input`: now handles MQTT messages and legacy webhook fields (old names mapped to new ones), rejects missing/NaN/out-of-range values and malformed JSON, never clamps or invents.
- `Build Safety Agent Request`: original prompt kept; now receives reading + rule results; new output fields (hazards with explanations/readings, recommended actions, uncertainty). **Prompt change:** your original forbade Agent 1 from recommending actions; your new requirements ask for them, so it may now suggest actions as recommendations only. It still cannot set the final status or contradict a rule-based DANGER.
- `Build Coordinator Agent Request`: receives readings + rule check + Agent 1 findings; told the rule status is a minimum.
- Both Groq nodes: only added "On Error: continue" so an API failure reaches the error path instead of crashing silently. URL, model, credential reference unchanged.
- `Parse Safety/Coordinator Output`: a small guard to show the real Groq error message; zone fallback adapted to the new structure.
- `Webhook` node: `webhookId` removed so n8n assigns its own on import (path stays `mine-safety`).

**Conflict resolution:** the rule status is a floor. AI may raise WARNING→DANGER, never lower DANGER→WARNING. If it tried, the final status stays at the rule level, `statusResolution.aiOverriddenByRules=true`, and the dashboard shows a notice. A Groq outage cannot hide a rule alert because that alert was already pushed.

## 4. Step-by-step (Windows)

Use **Command Prompt (cmd)**. "Terminal A/B/C…" means separate cmd windows.

### Step 1 – Save the files
Create `C:\coal-mine\` and save there: `sensor_simulator.py`, the workflow JSON, and the folder `dashboard-backend\`. Copy the contents of `frontend-updated\` over your `frontend\` folder (it only contains changed/new files, see `frontend-updated\CHANGES.md`). Also add this line to your real `frontend\.env`: `VITE_RELAY_URL=http://localhost:3001`.

### Step 2 – Verify Python and paho-mqtt (Terminal A)
```
python --version
pip install paho-mqtt
pip show paho-mqtt
```
(If `python` is not found, try `py --version` / `py -m pip install paho-mqtt` and use `py` below.)

### Step 3 – Start/verify Mosquitto
```
sc query mosquitto
net start mosquitto
netstat -ano | findstr 1883
```
`net start` needs an **Administrator** cmd. You should see `LISTENING` on port 1883. Mosquitto's `bin` folder (usually `C:\Program Files\mosquitto`) must be used for the next step.

### Step 4 – Test MQTT independently (before n8n)
Terminal B (subscriber):
```
cd "C:\Program Files\mosquitto"
mosquitto_sub -h localhost -p 1883 -t "mine/#" -v
```
Terminal A (simulator, 3 messages):
```
cd C:\coal-mine
python sensor_simulator.py --count 3 --interval 2
```
Terminal B must print each JSON message and Terminal A prints `[PUBLISHED #n]`. If the simulator starts before Mosquitto it prints `[WAIT] ...` and connects automatically once the broker is up.

### Step 5 – Start the dashboard backend (Terminal C)
```
cd C:\coal-mine\dashboard-backend
node server.js
```
Check http://localhost:3001/api/health in a browser (`{"ok":true,...}`). Leave it running.

### Step 6 – Import the workflow into n8n
1. Start n8n if needed (`n8n start`) and open http://localhost:5678.
2. **Deactivate your original workflow** (both use webhook path `mine-safety`; two active workflows would conflict).
3. Create a new workflow → ⋯ menu → **Import from file** → choose `Coal-Mine-Safety-Workflow-Groq-MQTT.json`. It imports as inactive.

### Step 7 – MQTT credentials
Open `MQTT Trigger - Sensor Readings` → Credential → **Create new**: Protocol `mqtt`, Host `localhost`, Port `1883`, leave Username/Password empty (default local Mosquitto), Save, then select it. Topic stays `mine/+/sensors`.
- **n8n in Docker:** host `host.docker.internal`; Mosquitto must listen beyond localhost. Add to `mosquitto.conf`: `listener 1883` and either `allow_anonymous true` (demo only, trusted network) or a password file, restart the service, and allow port 1883 in Windows Firewall. Also change the URL in `Push to Dashboard Backend` to `http://host.docker.internal:3001/api/ingest` and start the backend with `set HOST=0.0.0.0` first (it has no authentication).
- **Another machine:** use that machine's IP as host; run the simulator with `--host <IP>`.

### Step 8 – Re-select Groq credentials (no key in the file)
Open `Safety Analysis Agent (Groq)` and `Coordinator Agent (Groq)`; in Credential choose your existing **Groq API Key (Header Auth)** (the file only contains a placeholder ID `GROQ_API_KEY_CREDENTIAL_ID`). If you must recreate it: Header Auth, Name `Authorization`, Value `Bearer <your Groq key>` – never paste the key into nodes or chat.

### Step 9 – Run the workflow
- Test: click **Execute workflow**; the trigger waits ("Listening for test event"), then start the simulator (step 10). It handles one message per click.
- Continuous: toggle the workflow **Active** (or Publish in newer n8n). Executions then appear in the Executions tab.

### Step 10 – Start the simulator (Terminal A)
```
cd C:\coal-mine
python sensor_simulator.py
```
Useful flags: `--scenario normal|warning|danger`, `--interval 10`, `--invalid-every 5`, `--topic mine/zone2/sensors --zone "Zone 2"`.
**Rate limits:** every reading makes two Groq calls. The default interval is 10 s; 3–5 s is allowed but may cause HTTP 429 errors depending on your Groq plan (check your console limits).

### Step 11 – Start React (Terminal D)
```
cd C:\coal-mine\frontend
npm install
npm run dev
```
Open http://localhost:5173. The live panel appears above your existing form; the manual form and its Safe/Warning/Danger demo chips still call the n8n webhook as before. (`npm install` is only needed the first time; no new dependencies were added.)

### Step 12 – Verify the whole chain
1. Terminal A shows `[PUBLISHED ...]`. 2. Terminal B (mosquitto_sub) shows the same JSON. 3. n8n **Executions** shows a run per message with both Groq nodes green. 4. Terminal C logs `rule_alert` then `analysis`. 5. The dashboard updates without refresh; the reading card changes first, the AI card after a few seconds.

### Step 13 – Test scenarios
```
python sensor_simulator.py --scenario normal  --count 3
python sensor_simulator.py --scenario warning --count 3
python sensor_simulator.py --scenario danger  --count 3
python sensor_simulator.py --invalid-every 2 --count 6
```
Force an exact critical value without the simulator (Terminal B; save as `C:\coal-mine\critical.json`):
```
{"mine_zone":"Zone 1","mine_area":"Underground Tunnel","methane_level":1.8,"carbon_monoxide":10,"dust_level":0.6,"equipment_name":"Ventilation Fan","equipment_temperature":55,"vibration_level":2,"equipment_status":"RUNNING","worker_count":4,"timestamp":"2026-11-03T10:00:00Z","simulated":true,"data_source":"SIMULATED manual test"}
```
```
cd "C:\Program Files\mosquitto"
mosquitto_pub -h localhost -t mine/zone1/sensors -f C:\coal-mine\critical.json
```
(Use a current timestamp to avoid a "stale reading" warning.) Expected: rule status DANGER, final DANGER.
Legacy manual webhook still works:
```
curl -X POST http://localhost:5678/webhook/mine-safety -H "Content-Type: application/json" -d "{\"zone\":\"Zone 1\",\"mineName\":\"Mine A\",\"methane\":0.3,\"carbonMonoxide\":8,\"dustLevel\":\"Low\",\"equipment\":\"Fan\",\"temperature\":55,\"vibration\":\"Low\",\"equipmentStatus\":\"RUNNING\",\"workers\":3}"
```
(The production URL works only while the workflow is active.)

### Step 14 – Troubleshooting
| Symptom | Fix |
|---|---|
| Simulator keeps printing `[WAIT] Not connected` | Mosquitto not running (`net start mosquitto`), wrong host/port, firewall, or another program on 1883 (`netstat -ano \| findstr 1883`). |
| `ModuleNotFoundError: paho` | Installed into a different Python; use `python -m pip install paho-mqtt`. |
| Connection refused in n8n credential test | Wrong host (Docker needs `host.docker.internal` + non-localhost listener). |
| n8n receives nothing | Workflow not active/listening; topic mismatch (`mine/+/sensors` vs your `--topic`); check with `mosquitto_sub -t "mine/#" -v`. Use QoS 0/1 – both work. |
| Validation errors | Expected for `--invalid-every` tests; the message names the exact field. |
| Groq 401 | Credential missing/invalid header (`Authorization: Bearer ...`). |
| Groq 429 | Increase `--interval`; both agents call Groq per reading. |
| Groq model not found | Model name is unchanged from your workflow (`openai/gpt-oss-20b`); check it is still available to your account. |
| "Groq API error" on dashboard | See the message in the red box and n8n Executions for the HTTP response. |
| Webhook path in use on activation | Deactivate the original workflow first. |
| Dashboard says "Backend unreachable" | Backend not running or wrong `baseUrl`; test `/api/health`. |
| CORS error in browser console | Backend sends `Access-Control-Allow-Origin: *` by default; if you set `ALLOWED_ORIGIN`, it must exactly match your React origin (e.g. `http://localhost:5173`). Restart the backend. |
| Dashboard shows data but "STALE" | No reading for >30 s: simulator stopped, n8n inactive, or broker down. |
| n8n can't reach backend (Docker) | Use `host.docker.internal` URL and `HOST=0.0.0.0`. |

## 4b. Things to know about your existing form

- **Status words:** your form uses `Normal / Warning / Fault`. The validator maps `Normal`→`RUNNING`; `Fault` is treated as an equipment WARNING by the rule check.
- **Dust and vibration** on the manual form are `Low/Medium/High` words, not numbers, so the numeric dust/vibration rules are skipped for manual input (the words are still sent to the AI). MQTT readings use numbers (mg/m³, mm/s RMS).
- **Your demo chips will now classify differently.** Your "Warning" chip has methane 1.8%, which is at/above the 1.5% demo DANGER threshold, so the rule check (and therefore the final status) will be DANGER, not WARNING. Your "Safe" chip stays SAFE. Either lower that chip's methane to about 1.1, or change the thresholds in the `Local Rule Check` node.
- `zone` → `mine_zone` and `mineName` → `mine_area` for manual input.

## 5. Honest limitations
- I could not run live n8n, Mosquitto or paho-mqtt in my environment. I **did** run the Python generator logic, all JavaScript code nodes (validation, rules, prompt builders, rule-floor merge, including your form's values) with a Node test harness, and the backend with HTTP tests. The changed React files pass a JSX syntax check, but I could not run a Vite build (the `node_modules` in your zip is Windows-built), so check the browser console on first run. Import of the workflow JSON and the real MQTT/n8n/Groq round trip are untested – follow the verification steps above and report any node errors.
- The n8n branch ordering (rule alert before AI) relies on n8n's v1 execution order; confirm in an execution that `Push to Dashboard Backend` ran before the Groq nodes.
- Backend state is in memory (resets on restart) and unauthenticated – local development only.
