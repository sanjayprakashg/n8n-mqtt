# Coal Mine Safety Monitoring – MQTT Upgrade (SIMULATED DATA, DEMO ONLY)

Python simulator -> Mosquitto -> n8n (validate, local rules, Groq Safety Agent, Groq Coordinator) -> relay backend -> React dashboard.
Not a certified safety system. All sensor values are simulated.

## Folder contents
| Path | What |
|---|---|
| `sensor_simulator.py`, `requirements.txt` | Simulated sensor publisher |
| `Coal-Mine-Safety-Workflow-Groq-MQTT.json` | Import this into n8n (new workflow) |
| `original-n8n-workflow/` | Your original workflow, untouched |
| `dashboard-backend/` | Relay server (Node, no npm install) |
| `frontend/` | Your React app + live panel (run `npm install` once) |
| `1-start-backend.bat`, `2-start-frontend.bat`, `3-start-simulator.bat` | Double-click launchers |
| `SETUP_GUIDE.md` | Full step-by-step guide + troubleshooting |
| `THRESHOLDS_AND_TESTS.md` | Thresholds, sources, test checklist |

## Quick start (details in SETUP_GUIDE.md)
1. Unzip to `C:\coal-mine\`. Install Python, Node.js; run `pip install paho-mqtt`.
2. Make sure Mosquitto is running: `net start mosquitto` (Administrator cmd).
3. Double-click `1-start-backend.bat` (http://localhost:3001/api/health should answer).
4. In n8n (http://localhost:5678): deactivate your old workflow, import the MQTT workflow, create the MQTT credential (host `localhost`, port `1883`), select your Groq credential on both Groq nodes, then activate it.
5. Double-click `2-start-frontend.bat` and open http://localhost:5173.
6. Double-click `3-start-simulator.bat` (options: `--scenario danger`, `--interval 10`, `--invalid-every 5`).
