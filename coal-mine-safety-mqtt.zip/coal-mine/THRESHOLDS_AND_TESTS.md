# Thresholds, Conflict Rules and Test Checklist

**Demonstration settings only.** Review against the regulations that actually apply to you (for Indian coal mines, the Coal Mines Regulations and DGMS circulars; elsewhere the local authority) and with a qualified mine-safety professional before any real deployment. Edit them in the `CONFIG` object at the top of the `Local Rule Check` node.

## Thresholds (greater than or equal)

| Field | Unit | WARNING | DANGER | Basis |
|---|---|---|---|---|
| `methane_level` | % vol | 1.0 | 1.5 | US MSHA 30 CFR 75.323 sets action levels at 1.0% and 1.5% methane in working places/intake air (the 1.5% level requires withdrawal of persons and de-energizing equipment). Used here as demo levels, not as Indian requirements. |
| `carbon_monoxide` | ppm | 35 | 200 | NIOSH REL: 35 ppm 8-h TWA and 200 ppm ceiling (OSHA PEL 50 ppm TWA; IDLH 1200 ppm). |
| `dust_level` | mg/m³ | 1.5 | 3.0 | MSHA respirable coal mine dust limit 1.5 mg/m³ (0.5 mg/m³ for intake air). DANGER = 2x, an arbitrary demo choice. |
| `equipment_temperature` | °C | 70 | 90 | **Placeholder engineering values**, no regulatory source. Use the equipment manufacturer's limits. |
| `vibration_level` | mm/s RMS | 4.5 | 7.1 | **Illustrative** machine-vibration severity levels, not checked against a source in this session. Use manufacturer/ISO guidance for your machine class. |
| `equipment_status` | – | `WARNING` → WARNING | – | Informational: `STOPPED` is noted, not escalated. |

Compound rules (→ DANGER): methane ≥ warning **and** (temperature ≥ warning, vibration ≥ warning, or status WARNING) = possible ignition source; methane ≥ warning **and** CO ≥ warning = possible heating/fire. Workers present while status ≠ SAFE adds a note.

Caveats: CO and dust limits above are **time-weighted averages**, but the prototype compares **instantaneous** values. Real systems also depend on sensor location, calibration, averaging and alarm design.

## Plausibility ranges (validation rejects, never clamps)
methane 0–100 % vol · CO 0–10000 ppm · dust 0–100 mg/m³ · temperature −20–300 °C · vibration 0–100 mm/s · workers whole number 0–1000 · timestamp valid date. These detect sensor faults/garbage, they are not safety limits.

## Conflict resolution (AI vs rules)
`finalStatus = max(ruleStatus, coordinatorAiStatus)` with SAFE < WARNING < DANGER, done in code in `Enforce Rule Floor & Build Result`. The AI cannot lower a rule-based status; it may raise it. Rule hazards are always included. The rule alert is pushed to the dashboard before the AI runs. This is a software prototype safeguard, **not** a certified or fail-safe alarm: n8n, the broker, the PC and the network are all single points of failure.

## Test checklist

| # | Check | How | Expected |
|---|---|---|---|
| 1 | Python publishes valid JSON | `python sensor_simulator.py --count 3` | `[PUBLISHED #n]` with parseable JSON incl. `"simulated": true` and `units`. |
| 2 | Mosquitto receives messages | `mosquitto_sub -h localhost -t "mine/#" -v` | Same messages appear. |
| 3 | n8n receives each message | Executions tab | One execution per message. |
| 4 | Validation works | `--invalid-every 3` | Truncated JSON, missing `carbon_monoxide`, and `"not-a-number"` are each rejected with a specific message; no AI call; red error box on dashboard. |
| 5 | Out-of-range rejected | Publish `methane_level` 500 | Rejected as possible sensor fault. |
| 6 | Rule checker flags critical | `critical.json` (methane 1.8) | `ruleCheck.status = DANGER`, `critical = true`; dashboard shows DANGER rule badge **before** AI result arrives. |
| 7 | Rules independent of AI | Deactivate the Groq credential, send critical | Rule alert still shown; error box reports AI failure. |
| 8 | Safety Agent processes data | Open the Groq node output | JSON with `identified_hazards`, `recommended_actions`, `uncertainty`, no invented fields. |
| 9 | Coordinator produces final status | Open `Enforce Rule Floor` output | `status`, `hazards`, `actions`, `statusResolution`. |
| 10 | AI cannot downgrade | Edit the Coordinator HTTP node output (pin data) to `WARNING` while rule is DANGER | Final stays DANGER, `aiOverriddenByRules: true`. |
| 11 | Dashboard auto-updates | Keep React open, run simulator | Cards update without refresh; reading card and AI card show separate timestamps. |
| 12 | Stale data | Stop the simulator, wait 30 s | "STALE DATA" warning, reading card dimmed. |
| 13 | Broker down | `net stop mosquitto` | Simulator prints `[WAIT]`/disconnect and reconnects after `net start mosquitto`. |
| 14 | Backend down | Stop `server.js` | Dashboard shows "Backend unreachable"; n8n continues (push node continues on error); reconnects when backend returns. |
| 15 | Legacy webhook | `curl` command in guide | Same response shape as before (`status`, `riskLevel`, `zone`, `message`, `hazards`, `actions`, `agentAnalysis`, `priority`). |
| 16 | Ctrl+C | Press in simulator terminal | Clean shutdown message. |
