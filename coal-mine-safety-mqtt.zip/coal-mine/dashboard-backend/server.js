// server.js - dashboard relay for the Coal Mine Safety prototype (NO npm dependencies).
//
// Why this exists: a browser cannot receive pushes from n8n's MQTT-triggered workflow
// (there is no webhook caller waiting for a response). So n8n POSTs each result here,
// and the React dashboard listens to this server with Server-Sent Events (SSE).
//
//   n8n --POST /api/ingest--> this server --SSE /api/stream--> React
//   React can also GET /api/latest (used as a fallback / first load).
//
// Run:  node server.js        (default http://localhost:3001)
// Env:  PORT=3001  HOST=127.0.0.1  ALLOWED_ORIGIN=http://localhost:5173

const http = require('http');

const PORT = Number(process.env.PORT || 3001);
// 127.0.0.1 = only this PC. Use HOST=0.0.0.0 ONLY if n8n runs in Docker/another machine
// (this server has no authentication - keep it on a trusted local network).
const HOST = process.env.HOST || '127.0.0.1';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*'; // tighten for anything beyond local dev
const MAX_BODY = 512 * 1024;
const HISTORY_MAX = 50;

const state = {
  reading: null,        // latest validated sensor reading + rule check (arrives BEFORE the AI result)
  ruleCheck: null,
  readingId: null,
  readingReceivedAt: null,
  analysis: null,       // latest completed AI result (may belong to an older reading)
  lastError: null,
  counters: { readings: 0, analyses: 0, errors: 0 },
  history: []
};
const clients = new Set();

function snapshot() {
  return {
    serverTime: new Date().toISOString(),
    reading: state.reading, ruleCheck: state.ruleCheck, readingId: state.readingId,
    readingReceivedAt: state.readingReceivedAt,
    analysis: state.analysis,
    analysisPending: !!state.readingId && (!state.analysis || state.analysis.readingId !== state.readingId) &&
      !(state.lastError && state.lastError.readingId === state.readingId),
    lastError: state.lastError, counters: state.counters, history: state.history
  };
}
function broadcast() {
  const msg = `event: update\ndata: ${JSON.stringify(snapshot())}\n\n`;
  for (const res of clients) { try { res.write(msg); } catch (_) { clients.delete(res); } }
}
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', ALLOWED_ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}
function json(res, code, obj) {
  cors(res); res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj));
}

function ingest(ev) {
  if (!ev || typeof ev !== 'object' || typeof ev.event !== 'string') return 'Body must be a JSON object with an "event" field';
  const at = ev.receivedAt || new Date().toISOString();
  if (ev.event === 'rule_alert') {
    if (!ev.reading || !ev.ruleCheck) return 'rule_alert needs reading and ruleCheck';
    state.counters.readings++;
    // ignore out-of-order older readings (parallel n8n executions)
    if (!state.readingReceivedAt || at >= state.readingReceivedAt) {
      state.reading = ev.reading; state.ruleCheck = ev.ruleCheck; state.readingId = ev.readingId;
      state.readingReceivedAt = at; state.reading._source = ev.source; state.reading._warnings = ev.validationWarnings || [];
    }
  } else if (ev.event === 'analysis') {
    state.counters.analyses++;
    if (!state.analysis || (ev.receivedAt || '') >= (state.analysis.receivedAt || '')) state.analysis = ev;
    state.history.unshift({ at: ev.analyzedAt || at, zone: ev.zone, status: ev.status, summary: ev.message });
    state.history = state.history.slice(0, HISTORY_MAX);
  } else if (ev.event === 'error') {
    state.counters.errors++;
    state.lastError = { ...ev, at: new Date().toISOString() };
  } else return 'Unknown event type: ' + ev.event;
  broadcast();
  return null;
}

const server = http.createServer((req, res) => {
  const url = (req.url || '').split('?')[0];
  if (req.method === 'OPTIONS') { cors(res); res.writeHead(204); return res.end(); }

  if (req.method === 'GET' && url === '/api/health') return json(res, 200, { ok: true, clients: clients.size, serverTime: new Date().toISOString() });
  if (req.method === 'GET' && url === '/api/latest') return json(res, 200, snapshot());

  if (req.method === 'GET' && url === '/api/stream') {
    cors(res);
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write(`event: update\ndata: ${JSON.stringify(snapshot())}\n\n`);
    clients.add(res);
    const ka = setInterval(() => { try { res.write(': keepalive\n\n'); } catch (_) {} }, 15000);
    req.on('close', () => { clearInterval(ka); clients.delete(res); });
    return;
  }

  if (req.method === 'POST' && url === '/api/ingest') {
    let body = ''; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { req.destroy(); } else body += c; });
    req.on('end', () => {
      let ev; try { ev = JSON.parse(body); } catch (e) { return json(res, 400, { ok: false, error: 'Invalid JSON' }); }
      const err = ingest(ev);
      if (err) return json(res, 422, { ok: false, error: err });
      console.log(`[${new Date().toLocaleTimeString()}] ${ev.event}` + (ev.status ? ' ' + ev.status : '') + (ev.ruleCheck ? ' rules=' + ev.ruleCheck.status : '') + (ev.message && ev.event === 'error' ? ' - ' + ev.message : ''));
      json(res, 200, { ok: true });
    });
    return;
  }
  json(res, 404, { ok: false, error: 'Not found' });
});

server.listen(PORT, HOST, () => {
  console.log(`Dashboard relay listening on http://${HOST}:${PORT}`);
  console.log('  POST /api/ingest   <- n8n');
  console.log('  GET  /api/stream   -> React (SSE)');
  console.log('  GET  /api/latest   -> React (fallback)');
  console.log('  GET  /api/health');
});
