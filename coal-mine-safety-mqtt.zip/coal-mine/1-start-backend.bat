@echo off
title Dashboard backend
cd /d "%~dp0dashboard-backend"
node server.js
pause
