import { useState } from 'react'
import Header from './components/Header.jsx'
import SafetyForm from './components/SafetyForm.jsx'
import SafetyResult from './components/SafetyResult.jsx'
import AgentAnalysis from './components/AgentAnalysis.jsx'
import LiveMinePanel from './components/LiveMinePanel.jsx'
import { analyzeSafety, validateMineData, ErrorCodes, RELAY_URL } from './api.js'

const EMPTY_FORM = {
  zone: '',
  mineName: '',
  methane: '',
  carbonMonoxide: '',
  dustLevel: '',
  equipment: '',
  temperature: '',
  vibration: '',
  equipmentStatus: '',
  workers: '',
}

const PIPELINE_STEPS = [
  'Sending data to n8n',
  'Safety Analysis Agent evaluating conditions',
  'Coordinator Agent determining overall risk',
  'Formatting result',
]

const ERROR_MESSAGES = {
  [ErrorCodes.NETWORK]: 'Unable to reach the n8n workflow. Please check that n8n is running and try again.',
  [ErrorCodes.TIMEOUT]: 'The analysis timed out. The n8n workflow or AI model API may be slow right now — please try again.',
  [ErrorCodes.SERVER]: 'The n8n workflow reported an error while analyzing the mine conditions. Please check the workflow and try again.',
  [ErrorCodes.BAD_RESPONSE]: 'The workflow returned an unexpected response format. Please check the n8n workflow configuration.',
  [ErrorCodes.UNKNOWN]: 'Something went wrong while analyzing the mine conditions. Please try again.',
}

export default function App() {
  const [formData, setFormData] = useState(EMPTY_FORM)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [pipelineStep, setPipelineStep] = useState(0)
  const [result, setResult] = useState(null)
  const [errorMessage, setErrorMessage] = useState(null)

  const handleFieldChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setErrors((prev) => ({ ...prev, [field]: undefined }))
  }

  const handleFillTestCase = (testCase) => {
    setFormData(testCase)
    setErrors({})
    setResult(null)
    setErrorMessage(null)
  }

  const handleSubmit = async () => {
    setErrorMessage(null)
    setResult(null)

    const { isValid, errors: validationErrors } = validateMineData(formData)
    if (!isValid) {
      setErrors(validationErrors)
      return
    }

    const payload = {
      zone: formData.zone.trim(),
      mineName: formData.mineName.trim(),
      methane: Number(formData.methane),
      carbonMonoxide: Number(formData.carbonMonoxide),
      dustLevel: formData.dustLevel,
      equipment: formData.equipment.trim(),
      temperature: Number(formData.temperature),
      vibration: formData.vibration,
      equipmentStatus: formData.equipmentStatus,
      workers: Number(formData.workers),
    }

    setLoading(true)
    setPipelineStep(0)

    // Purely cosmetic step-through so the audience can see the pipeline
    // "moving" while the real request is in flight.
    const stepTimer = setInterval(() => {
      setPipelineStep((s) => (s < PIPELINE_STEPS.length - 1 ? s + 1 : s))
    }, 900)

    try {
      const data = await analyzeSafety(payload)
      setResult(data)
    } catch (err) {
      setErrorMessage(ERROR_MESSAGES[err.code] || ERROR_MESSAGES[ErrorCodes.UNKNOWN])
    } finally {
      clearInterval(stepTimer)
      setLoading(false)
    }
  }

  return (
    <div className="app-shell">
      <Header />

      {/* NEW: live MQTT -> n8n -> relay feed (simulated sensors). The manual form below still works. */}
      <section className="panel panel--live">
        <LiveMinePanel baseUrl={RELAY_URL} />
      </section>

      <main className="app-main">
        <section className="panel panel--form">
          <h2 className="panel__title">Mine Condition Input</h2>
          <SafetyForm
            data={formData}
            errors={errors}
            loading={loading}
            onChange={handleFieldChange}
            onSubmit={handleSubmit}
            onFillTestCase={handleFillTestCase}
          />
        </section>

        <section className="panel panel--result">
          <h2 className="panel__title">Risk Analysis</h2>

          {loading && (
            <div className="pipeline">
              <p className="pipeline__status">Analyzing mine conditions…</p>
              <ol className="pipeline__steps">
                {PIPELINE_STEPS.map((step, i) => (
                  <li
                    key={step}
                    className={
                      i < pipelineStep ? 'is-done' : i === pipelineStep ? 'is-active' : ''
                    }
                  >
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          )}

          {!loading && errorMessage && (
            <div className="error-banner" role="alert">
              <strong>Analysis failed.</strong>
              <p>{errorMessage}</p>
            </div>
          )}

          {!loading && !errorMessage && !result && (
            <div className="empty-state">
              <p>Fill in the mine conditions and click <strong>Analyze Safety</strong> to run the two-agent risk assessment.</p>
            </div>
          )}

          {!loading && result && (
            <>
              <SafetyResult result={result} />
              <AgentAnalysis result={result} />
            </>
          )}

          <p className="disclaimer">
            This prototype provides AI-assisted risk analysis and recommendations. It does not
            replace professional mine safety procedures. All thresholds used in this demo are
            configurable placeholder values for demonstration only — actual operational limits
            must come from applicable mining regulations and qualified safety professionals. No
            equipment is controlled by this system; all actions are recommendations only.
          </p>
        </section>
      </main>
    </div>
  )
}
