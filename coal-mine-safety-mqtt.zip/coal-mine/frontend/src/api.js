import axios from 'axios'

/**
 * ---------------------------------------------------------------------------
 * n8n webhook connection
 * ---------------------------------------------------------------------------
 * This is the ONLY place the frontend talks to the outside world. React does
 * not talk to Gemini directly and does not need its own backend server -
 * n8n's webhook acts as the API endpoint.
 *
 * Change this value if your n8n instance runs somewhere else (e.g. n8n Cloud
 * gives you a URL like https://your-instance.app.n8n.cloud/webhook/mine-safety)
 * ---------------------------------------------------------------------------
 */
export const N8N_WEBHOOK_URL =
  import.meta.env.VITE_N8N_WEBHOOK_URL || 'http://localhost:5678/webhook/mine-safety'

/**
 * NEW: base URL of the dashboard relay (dashboard-backend/server.js) that streams
 * MQTT-triggered n8n results to the live panel.
 */
export const RELAY_URL = import.meta.env.VITE_RELAY_URL || 'http://localhost:3001'

const REQUEST_TIMEOUT_MS = 45000 // AI model calls (x2, chained) can take a while

/**
 * A small set of custom error "codes" so the UI can show a specific,
 * friendly message instead of a raw stack trace.
 */
export const ErrorCodes = {
  NETWORK: 'NETWORK',
  TIMEOUT: 'TIMEOUT',
  SERVER: 'SERVER',
  BAD_RESPONSE: 'BAD_RESPONSE',
  VALIDATION: 'VALIDATION',
  UNKNOWN: 'UNKNOWN',
}

class SafetyApiError extends Error {
  constructor(code, message, details) {
    super(message)
    this.code = code
    this.details = details
  }
}

/**
 * Basic client-side validation before we even hit the network.
 * Mirrors (but does not replace) the validation done inside n8n.
 */
export function validateMineData(data) {
  const errors = {}

  if (!data.zone || !data.zone.trim()) errors.zone = 'Mine zone is required'
  if (!data.mineName || !data.mineName.trim()) errors.mineName = 'Mine/area name is required'

  if (data.methane === '' || data.methane === null || isNaN(Number(data.methane))) {
    errors.methane = 'Enter a valid methane level (%)'
  } else if (Number(data.methane) < 0) {
    errors.methane = 'Methane level cannot be negative'
  }

  if (data.carbonMonoxide === '' || data.carbonMonoxide === null || isNaN(Number(data.carbonMonoxide))) {
    errors.carbonMonoxide = 'Enter a valid CO level (ppm)'
  } else if (Number(data.carbonMonoxide) < 0) {
    errors.carbonMonoxide = 'CO level cannot be negative'
  }

  if (!data.dustLevel) errors.dustLevel = 'Select a dust level'

  if (!data.equipment || !data.equipment.trim()) errors.equipment = 'Equipment name is required'

  if (data.temperature === '' || data.temperature === null || isNaN(Number(data.temperature))) {
    errors.temperature = 'Enter a valid equipment temperature (°C)'
  }

  if (!data.vibration) errors.vibration = 'Select a vibration level'
  if (!data.equipmentStatus) errors.equipmentStatus = 'Select an equipment status'

  if (data.workers === '' || data.workers === null || isNaN(Number(data.workers))) {
    errors.workers = 'Enter a valid number of workers'
  } else if (Number(data.workers) < 0) {
    errors.workers = 'Number of workers cannot be negative'
  }

  return { isValid: Object.keys(errors).length === 0, errors }
}

/**
 * Sends the mine-condition payload to the n8n webhook and returns the
 * parsed, structured result produced by the two agents.
 *
 * Throws a SafetyApiError with a `.code` the UI can branch on.
 */
export async function analyzeSafety(payload) {
  try {
    const response = await axios.post(N8N_WEBHOOK_URL, payload, {
      timeout: REQUEST_TIMEOUT_MS,
      headers: { 'Content-Type': 'application/json' },
    })

    const result = response.data

    if (!result || typeof result !== 'object') {
      throw new SafetyApiError(
        ErrorCodes.BAD_RESPONSE,
        'The workflow returned an empty or unreadable response.'
      )
    }

    // n8n's own error branch (see workflow's "Handle Agent Error" node)
    if (result.error) {
      throw new SafetyApiError(
        ErrorCodes.SERVER,
        result.message || 'The AI agents could not complete the analysis.'
      )
    }

    const requiredFields = ['status', 'riskLevel', 'zone', 'message', 'hazards', 'actions']
    const missing = requiredFields.filter((f) => !(f in result))
    if (missing.length > 0) {
      throw new SafetyApiError(
        ErrorCodes.BAD_RESPONSE,
        `The workflow response was missing expected fields: ${missing.join(', ')}`
      )
    }

    return result
  } catch (err) {
    if (err instanceof SafetyApiError) throw err

    if (axios.isAxiosError(err)) {
      if (err.code === 'ECONNABORTED') {
        throw new SafetyApiError(
          ErrorCodes.TIMEOUT,
          'The analysis took too long to respond. The n8n workflow or AI model API may be slow or unreachable.'
        )
      }
      if (!err.response) {
        throw new SafetyApiError(
          ErrorCodes.NETWORK,
          'Could not reach the n8n workflow. Check that n8n is running and the webhook URL is correct.'
        )
      }
      throw new SafetyApiError(
        ErrorCodes.SERVER,
        `The n8n workflow returned an error (HTTP ${err.response.status}).`,
        err.response.data
      )
    }

    throw new SafetyApiError(ErrorCodes.UNKNOWN, 'An unexpected error occurred while analyzing mine conditions.')
  }
}

export { SafetyApiError }
