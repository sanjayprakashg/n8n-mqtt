export default function Header() {
  return (
    <header className="app-header">
      <div className="app-header__brand">
        <div className="app-header__mark" aria-hidden="true">⛏</div>
        <div>
          <h1>Coal Mine Safety Monitoring System</h1>
          <p className="app-header__subtitle">Agentic AI Multi-Agent Safety Analysis</p>
        </div>
      </div>
      <div className="app-header__badge">
        <span className="dot dot--pulse" /> Prototype · 2 agents · n8n orchestrated
      </div>
    </header>
  )
}
