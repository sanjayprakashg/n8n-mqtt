import useMineStream from '../hooks/useMineStream.js'
import './LiveMinePanel.css'

// Two clearly separated blocks:
//   1) LATEST SENSOR READING (simulated) + local rule-check status  (arrives first)
//   2) AI ANALYSIS RESULT (Safety Analysis Agent + Coordinator, final status)  (arrives later)

const STATUS_CLASS = { SAFE: 'safe', WARNING: 'warning', DANGER: 'danger' }
const fmt = (v, unit) => (v === null || v === undefined ? 'n/a' : `${v}${unit ? ' ' + unit : ''}`)
const timeStr = (iso) => (iso ? new Date(iso).toLocaleString() : 'n/a')

function Badge({ status }) {
  const cls = STATUS_CLASS[status] || 'unknown'
  return <span className={`lmp-badge lmp-badge--${cls}`}>{status || 'UNKNOWN'}</span>
}
function Row({ label, value }) {
  return (
    <div className="lmp-row">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

export default function LiveMinePanel({ baseUrl = 'http://localhost:3001', staleAfterMs = 30000 }) {
  const { data, connection, stale, ageMs } = useMineStream({ baseUrl, staleAfterMs })
  const r = data?.reading
  const rc = data?.ruleCheck
  const a = data?.analysis
  const err = data?.lastError
  const analysisIsForLatest = a && data.readingId && a.readingId === data.readingId
  const connLabel = {
    live: 'Connected (live)',
    polling: 'Connected (polling)',
    connecting: 'Connecting…',
    offline: 'Live relay unreachable',
  }[connection]
  const finalClass = STATUS_CLASS[a?.status] || 'unknown'

  return (
    <div className="lmp">
      <div className="lmp-head">
        <h2 className="panel__title lmp-title">Live Mine Monitoring (MQTT)</h2>
        <div className="lmp-conn">
          <span className={`lmp-dot lmp-dot--${connection}`} /> {connLabel}
          {stale && <span className="lmp-stale"> · STALE: no new reading for {Math.round(ageMs / 1000)} s</span>}
        </div>
      </div>

      {!r && (
        <div className="empty-state">
          <p>Waiting for the first sensor reading… Start the simulator and make sure the n8n workflow is active and the relay backend is running.</p>
        </div>
      )}

      {r && (
        <div className="lmp-grid">
          {/* -------- BLOCK 1: sensor reading -------- */}
          <div className={`lmp-card ${stale ? 'lmp-card--stale' : ''}`}>
            <h3 className="lmp-card__title">
              Latest sensor reading {r.simulated && <span className="lmp-sim">SIMULATED</span>}
            </h3>
            <Row label="Mine zone" value={r.mine_zone} />
            <Row label="Mine / area" value={r.mine_area} />
            <Row label="Methane" value={fmt(r.methane_level, '% vol')} />
            <Row label="Carbon monoxide" value={fmt(r.carbon_monoxide, 'ppm')} />
            <Row label="Dust" value={r.dust_level === null && r.dust_level_text ? r.dust_level_text : fmt(r.dust_level, 'mg/m³')} />
            <Row label="Equipment" value={`${r.equipment_name} (${r.equipment_status})`} />
            <Row label="Equipment temp." value={fmt(r.equipment_temperature, '°C')} />
            <Row label="Vibration" value={r.vibration_level === null && r.vibration_level_text ? r.vibration_level_text : fmt(r.vibration_level, 'mm/s RMS')} />
            <Row label="Workers present" value={fmt(r.worker_count)} />
            <Row label="Reading time" value={timeStr(r.timestamp)} />
            <Row label="Source" value={r._source === 'webhook' ? 'Manual form (webhook)' : r.data_source || 'MQTT'} />
            {rc && (
              <div className="lmp-rules">
                <div>
                  <strong>Local rule check (no AI):</strong> <Badge status={rc.status} />
                </div>
                {rc.triggered.length === 0 && <div className="lmp-muted">No configured thresholds exceeded.</div>}
                <ul>
                  {rc.triggered.map((t) => (
                    <li key={t.rule_id}>{t.message}</li>
                  ))}
                </ul>
                <div className="lmp-muted">Demonstration thresholds, not a certified alarm.</div>
              </div>
            )}
          </div>

          {/* -------- BLOCK 2: AI analysis -------- */}
          <div className={`lmp-card status-card status-card--${finalClass}`}>
            <h3 className="lmp-card__title">AI analysis result</h3>
            {!a && <p className="lmp-muted">{data.analysisPending ? 'AI agents are analysing the latest reading…' : 'No AI result yet.'}</p>}
            {a && (
              <>
                <div className="lmp-final">
                  Final status: <Badge status={a.status} /> <span className="lmp-muted">risk {a.riskLevel}</span>
                </div>
                {!analysisIsForLatest && (
                  <div className="lmp-note">
                    {data.analysisPending
                      ? 'This result is for an EARLIER reading; the newest reading is still being analysed.'
                      : 'This result is for an earlier reading.'}
                  </div>
                )}
                <Row label="Analysed at" value={timeStr(a.analyzedAt)} />
                <Row label="Zone / area" value={`${a.reading?.mine_zone ?? a.zone} / ${a.reading?.mine_area ?? 'n/a'}`} />
                <p className="lmp-summary">{a.message}</p>
                {a.statusResolution?.aiOverriddenByRules && (
                  <div className="lmp-note">
                    AI said {a.statusResolution.aiStatus}; the rule-based status ({a.statusResolution.ruleStatus}) was kept.
                  </div>
                )}
                <div className="result-columns">
                  <div className="result-list">
                    <h3>Detected hazards</h3>
                    {a.hazards?.length ? <ul>{a.hazards.map((h, i) => <li key={i}>{h}</li>)}</ul> : <p className="result-list__empty">None detected.</p>}
                  </div>
                  <div className="result-list">
                    <h3>Recommended actions</h3>
                    <ul>{(a.actions || []).map((x, i) => <li key={i}>{x}</li>)}</ul>
                  </div>
                </div>
                {a.agentAnalysis?.safetyAgent && (
                  <details className="lmp-details">
                    <summary>Safety Analysis Agent details</summary>
                    <Row label="Gas risk" value={a.agentAnalysis.safetyAgent.gasRisk} />
                    <Row label="Dust risk" value={a.agentAnalysis.safetyAgent.dustRisk} />
                    <Row label="Equipment risk" value={a.agentAnalysis.safetyAgent.equipmentRisk} />
                    <Row label="Worker risk" value={a.agentAnalysis.safetyAgent.workerRisk} />
                    <ul>{(a.agentAnalysis.safetyAgent.findings || []).map((f, i) => <li key={i}>{f}</li>)}</ul>
                    {a.agentAnalysis.safetyAgent.uncertainty?.length > 0 && (
                      <div className="lmp-muted">Uncertainty: {a.agentAnalysis.safetyAgent.uncertainty.join('; ')}</div>
                    )}
                  </details>
                )}
                <div className="lmp-muted">AI output is advisory only and can be wrong.</div>
              </>
            )}
          </div>
        </div>
      )}

      {err && (
        <div className="error-banner" role="alert">
          <strong>Last rejected / failed message ({err.stage}).</strong>
          <p>{err.message}</p>
          <p className="lmp-muted">
            {timeStr(err.at)} · totals: {data.counters.readings} readings, {data.counters.analyses} analyses, {data.counters.errors} errors
          </p>
        </div>
      )}
      <p className="lmp-muted lmp-foot">Simulated data for demonstration. Not a certified mine-safety system.</p>
    </div>
  )
}
