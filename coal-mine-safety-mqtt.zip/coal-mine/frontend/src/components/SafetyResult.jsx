const STATUS_META = {
  SAFE: { emoji: '🟢', label: 'SAFE', className: 'status-card--safe' },
  WARNING: { emoji: '🟡', label: 'WARNING', className: 'status-card--warning' },
  DANGER: { emoji: '🔴', label: 'DANGER', className: 'status-card--danger' },
}

// Fallback used only if the AI returns something outside the three allowed
// values - the UI must never crash or silently show nothing.
const UNKNOWN_META = { emoji: '⚪', label: 'UNKNOWN', className: 'status-card--unknown' }

export default function SafetyResult({ result }) {
  const meta = STATUS_META[result.status] || UNKNOWN_META

  return (
    <div className={`status-card ${meta.className}`}>
      <div className="status-card__top">
        <span className="status-card__emoji" aria-hidden="true">{meta.emoji}</span>
        <div>
          <div className="status-card__label">{meta.label}</div>
          <div className="status-card__risk">Risk Level: {result.riskLevel || 'N/A'}</div>
        </div>
      </div>

      <div className="status-card__meta">
        <span>Zone: <strong>{result.zone || '—'}</strong></span>
      </div>

      <p className="status-card__message">{result.message}</p>

      <div className="result-columns">
        <ResultList title="Detected Hazards" items={result.hazards} emptyText="No hazards detected." />
        <ResultList title="Recommended Actions" items={result.actions} emptyText="No actions recommended." />
      </div>
    </div>
  )
}

function ResultList({ title, items, emptyText }) {
  return (
    <div className="result-list">
      <h3>{title}</h3>
      {items && items.length > 0 ? (
        <ul>
          {items.map((item, i) => (
            <li key={i}>{item}</li>
          ))}
        </ul>
      ) : (
        <p className="result-list__empty">{emptyText}</p>
      )}
    </div>
  )
}
