const TEST_CASES = {
  safe: {
    zone: 'A1',
    mineName: 'North Ridge Coal Mine',
    methane: 0.4,
    carbonMonoxide: 5,
    dustLevel: 'Low',
    equipment: 'Conveyor Belt A1',
    temperature: 42,
    vibration: 'Low',
    equipmentStatus: 'Normal',
    workers: 10,
  },
  warning: {
    zone: 'C3',
    mineName: 'North Ridge Coal Mine',
    methane: 1.8,
    carbonMonoxide: 18,
    dustLevel: 'Medium',
    equipment: 'Ventilation Fan C3',
    temperature: 68,
    vibration: 'Medium',
    equipmentStatus: 'Warning',
    workers: 16,
  },
  danger: {
    zone: 'B2',
    mineName: 'Demo Coal Mine',
    methane: 4.2,
    carbonMonoxide: 35,
    dustLevel: 'High',
    equipment: 'Conveyor',
    temperature: 105,
    vibration: 'High',
    equipmentStatus: 'Warning',
    workers: 25,
  },
}

export default function SafetyForm({ data, errors, loading, onChange, onSubmit, onFillTestCase }) {
  const handleField = (field) => (e) => {
    onChange(field, e.target.value)
  }

  return (
    <form
      className="safety-form"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit()
      }}
      noValidate
    >
      <div className="form-toolbar">
        <span className="form-toolbar__label">Load demo readings:</span>
        <button type="button" className="chip chip--safe" onClick={() => onFillTestCase(TEST_CASES.safe)}>
          Safe
        </button>
        <button type="button" className="chip chip--warning" onClick={() => onFillTestCase(TEST_CASES.warning)}>
          Warning
        </button>
        <button type="button" className="chip chip--danger" onClick={() => onFillTestCase(TEST_CASES.danger)}>
          Danger
        </button>
      </div>

      {/* MINE INFORMATION */}
      <fieldset className="form-section">
        <legend>Mine Information</legend>
        <div className="form-grid form-grid--2">
          <Field label="Mine Zone" error={errors.zone}>
            <input
              type="text"
              placeholder="e.g. B2"
              value={data.zone}
              onChange={handleField('zone')}
            />
          </Field>
          <Field label="Mine / Area Name" error={errors.mineName}>
            <input
              type="text"
              placeholder="e.g. Demo Coal Mine"
              value={data.mineName}
              onChange={handleField('mineName')}
            />
          </Field>
        </div>
      </fieldset>

      {/* GAS CONDITIONS */}
      <fieldset className="form-section">
        <legend>Gas Conditions</legend>
        <div className="form-grid form-grid--2">
          <Field label="Methane level (%)" error={errors.methane} hint="Demo scale, not a regulatory threshold">
            <input
              type="number"
              step="0.1"
              min="0"
              placeholder="e.g. 1.2"
              value={data.methane}
              onChange={handleField('methane')}
            />
          </Field>
          <Field label="Carbon Monoxide level (ppm)" error={errors.carbonMonoxide} hint="Demo scale, not a regulatory threshold">
            <input
              type="number"
              step="1"
              min="0"
              placeholder="e.g. 12"
              value={data.carbonMonoxide}
              onChange={handleField('carbonMonoxide')}
            />
          </Field>
        </div>
      </fieldset>

      {/* ENVIRONMENTAL CONDITIONS */}
      <fieldset className="form-section">
        <legend>Environmental Conditions</legend>
        <div className="form-grid form-grid--1">
          <Field label="Dust level" error={errors.dustLevel}>
            <select value={data.dustLevel} onChange={handleField('dustLevel')}>
              <option value="">Select…</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </Field>
        </div>
      </fieldset>

      {/* EQUIPMENT HEALTH */}
      <fieldset className="form-section">
        <legend>Equipment Health</legend>
        <div className="form-grid form-grid--2">
          <Field label="Equipment name" error={errors.equipment}>
            <input
              type="text"
              placeholder="e.g. Conveyor"
              value={data.equipment}
              onChange={handleField('equipment')}
            />
          </Field>
          <Field label="Equipment temperature (°C)" error={errors.temperature}>
            <input
              type="number"
              step="1"
              placeholder="e.g. 68"
              value={data.temperature}
              onChange={handleField('temperature')}
            />
          </Field>
          <Field label="Vibration level" error={errors.vibration}>
            <select value={data.vibration} onChange={handleField('vibration')}>
              <option value="">Select…</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </Field>
          <Field label="Equipment status" error={errors.equipmentStatus}>
            <select value={data.equipmentStatus} onChange={handleField('equipmentStatus')}>
              <option value="">Select…</option>
              <option value="Normal">Normal</option>
              <option value="Warning">Warning</option>
              <option value="Fault">Fault</option>
            </select>
          </Field>
        </div>
      </fieldset>

      {/* WORKFORCE */}
      <fieldset className="form-section">
        <legend>Workforce</legend>
        <div className="form-grid form-grid--1">
          <Field label="Number of workers present" error={errors.workers}>
            <input
              type="number"
              step="1"
              min="0"
              placeholder="e.g. 25"
              value={data.workers}
              onChange={handleField('workers')}
            />
          </Field>
        </div>
      </fieldset>

      <button type="submit" className="btn-analyze" disabled={loading}>
        {loading ? 'Analyzing…' : 'Analyze Safety'}
      </button>
    </form>
  )
}

function Field({ label, error, hint, children }) {
  return (
    <label className={`field ${error ? 'field--error' : ''}`}>
      <span className="field__label">{label}</span>
      {children}
      {hint && !error && <span className="field__hint">{hint}</span>}
      {error && <span className="field__error">{error}</span>}
    </label>
  )
}
