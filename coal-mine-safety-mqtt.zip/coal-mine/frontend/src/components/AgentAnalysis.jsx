export default function AgentAnalysis({ result }) {
  const safety = result.agentAnalysis?.safetyAgent
  const coordinator = result.agentAnalysis?.coordinatorAgent

  return (
    <div className="agent-analysis">
      <h3 className="agent-analysis__heading">Agent Communication Trail</h3>
      <div className="agent-flow">
        <div className="agent-card">
          <div className="agent-card__header">
            <span className="agent-card__index">Agent 1</span>
            <span className="agent-card__name">Safety Analysis Agent</span>
          </div>
          <dl className="agent-card__grid">
            <dt>Gas risk</dt>
            <dd>{safety?.gasRisk || 'N/A'}</dd>
            <dt>Equipment risk</dt>
            <dd>{safety?.equipmentRisk || 'N/A'}</dd>
            <dt>Worker risk</dt>
            <dd>{safety?.workerRisk || 'N/A'}</dd>
          </dl>
          {safety?.findings?.length > 0 && (
            <ul className="agent-card__findings">
              {safety.findings.map((f, i) => (
                <li key={i}>{f}</li>
              ))}
            </ul>
          )}
        </div>

        <div className="agent-arrow" aria-hidden="true">→</div>

        <div className="agent-card agent-card--coordinator">
          <div className="agent-card__header">
            <span className="agent-card__index">Agent 2</span>
            <span className="agent-card__name">Coordinator Agent</span>
          </div>
          <dl className="agent-card__grid">
            <dt>Overall status</dt>
            <dd>{coordinator?.status || result.status}</dd>
            <dt>Risk level</dt>
            <dd>{coordinator?.riskLevel || result.riskLevel}</dd>
          </dl>
          <p className="agent-card__final-message">{coordinator?.finalMessage || result.message}</p>
        </div>
      </div>
    </div>
  )
}
