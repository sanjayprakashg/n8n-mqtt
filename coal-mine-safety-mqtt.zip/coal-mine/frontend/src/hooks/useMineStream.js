// useMineStream.js - receives live data from the dashboard relay (dashboard-backend/server.js).
// Uses Server-Sent Events (EventSource); falls back to polling /api/latest if SSE fails.
// Also computes "stale" (no new sensor reading for staleAfterMs).
import { useEffect, useState } from 'react'

export default function useMineStream({ baseUrl = 'http://localhost:3001', staleAfterMs = 30000, pollMs = 5000 } = {}) {
  const [data, setData] = useState(null)
  const [connection, setConnection] = useState('connecting') // connecting | live | polling | offline
  const [now, setNow] = useState(Date.now())

  // tick once a second so "stale" updates even when no data arrives
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    let es = null
    let pollTimer = null
    let cancelled = false

    const startPolling = () => {
      if (pollTimer || cancelled) return
      const poll = async () => {
        try {
          const r = await fetch(`${baseUrl}/api/latest`)
          if (!r.ok) throw new Error(String(r.status))
          setData(await r.json())
          setConnection('polling')
        } catch (_) {
          setConnection('offline')
        }
      }
      poll()
      pollTimer = setInterval(poll, pollMs)
    }

    if (typeof EventSource === 'undefined') {
      startPolling()
    } else {
      es = new EventSource(`${baseUrl}/api/stream`)
      es.onopen = () => {
        if (pollTimer) { clearInterval(pollTimer); pollTimer = null }
        setConnection('live')
      }
      es.addEventListener('update', (e) => {
        try { setData(JSON.parse(e.data)); setConnection('live') } catch (_) { /* ignore bad frame */ }
      })
      // EventSource reconnects by itself; polling covers the gap
      es.onerror = () => { setConnection('offline'); startPolling() }
    }
    return () => {
      cancelled = true
      if (es) es.close()
      if (pollTimer) clearInterval(pollTimer)
    }
  }, [baseUrl, pollMs])

  const receivedAt = data && data.readingReceivedAt ? Date.parse(data.readingReceivedAt) : null
  const ageMs = receivedAt ? now - receivedAt : null
  const stale = ageMs !== null && ageMs > staleAfterMs
  return { data, connection, stale, ageMs }
}
