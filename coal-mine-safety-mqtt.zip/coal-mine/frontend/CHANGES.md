# Frontend changes (overlay: copy these files over your `frontend/` folder)

| File | Change |
|---|---|
| `src/components/LiveMinePanel.jsx` + `.css` | NEW live panel (sensor reading block + AI result block, connection/stale status). Uses your existing CSS variables and classes. |
| `src/hooks/useMineStream.js` | NEW: Server-Sent Events client with polling fallback and stale detection. |
| `src/App.jsx` | Added the import, `RELAY_URL`, and a `<section className="panel panel--live">` above `<main>`. Manual form, pipeline animation, SafetyResult and AgentAnalysis are unchanged. "Gemini" wording in one error message changed to "AI model" (your workflow uses Groq). |
| `src/api.js` | Added `export const RELAY_URL` (from `VITE_RELAY_URL`); "Gemini" wording in two error strings changed to "AI model". `analyzeSafety` and the webhook call are unchanged. |
| `.env.example` | Added `VITE_RELAY_URL=http://localhost:3001`. Your real `.env` is untouched: add the same line to it. |

Not changed: `styles.css`, `Header.jsx`, `SafetyForm.jsx`, `SafetyResult.jsx`, `AgentAnalysis.jsx`, `package.json` (no new dependencies).
