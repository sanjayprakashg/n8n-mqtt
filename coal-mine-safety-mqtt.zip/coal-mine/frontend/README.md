# Frontend — Coal Mine Safety Monitoring Dashboard

React + Vite dashboard that collects mine-condition data and calls the n8n
webhook directly (no custom backend needed).

## Setup

```bash
npm install
cp .env.example .env   # edit VITE_N8N_WEBHOOK_URL if needed
npm run dev
```

Open the URL Vite prints (default `http://localhost:5173`).

## Files

- `src/api.js` — the only file that talks to the network. Validates form data client-side, POSTs to the n8n webhook, and turns network/parse failures into friendly error codes.
- `src/App.jsx` — top-level state: form data, loading/pipeline animation, result, errors.
- `src/components/Header.jsx` — title bar.
- `src/components/SafetyForm.jsx` — the input form, grouped into the 5 required sections, plus "load demo readings" chips for Safe/Warning/Danger test cases.
- `src/components/SafetyResult.jsx` — the big status card. **Colors are decided entirely in this file based on the `status` string** (`SAFE`/`WARNING`/`DANGER`) — the AI never sends CSS or colors.
- `src/components/AgentAnalysis.jsx` — shows Agent 1 (Safety Analysis Agent) and Agent 2 (Coordinator Agent) outputs side by side, to make the agent hand-off visible during a demo.
- `src/styles.css` — all styling, plain CSS (no UI framework).

## Build for production

```bash
npm run build
npm run preview
```
