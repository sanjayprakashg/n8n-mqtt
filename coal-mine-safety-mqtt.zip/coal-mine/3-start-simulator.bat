@echo off
title Sensor simulator (SIMULATED data)
cd /d "%~dp0"
python sensor_simulator.py %*
pause
