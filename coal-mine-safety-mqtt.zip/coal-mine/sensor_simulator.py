#!/usr/bin/env python3
"""
sensor_simulator.py
===================
SIMULATED coal-mine sensor publisher for the
"Agentic AI-Based Coal Mine Safety Monitoring and Risk Coordination System".

*** EVERYTHING THIS PROGRAM PRODUCES IS SIMULATED. ***
*** These are random demo values, NOT measurements from a real mine. ***

What it does
------------
Generates a new fake sensor reading every few seconds and publishes it as a
JSON message to a Mosquitto MQTT broker. n8n subscribes to the same topic.

Quick start (Windows Command Prompt)
------------------------------------
    pip install paho-mqtt
    python sensor_simulator.py                       # random normal/warning/danger mix
    python sensor_simulator.py --scenario normal     # only normal readings
    python sensor_simulator.py --scenario warning    # only warning-level readings
    python sensor_simulator.py --scenario danger     # only critical readings
    python sensor_simulator.py --interval 10         # one reading every 10 seconds
    python sensor_simulator.py --invalid-every 5     # every 5th message is deliberately bad

Units used in every message (also included in the "units" field)
----------------------------------------------------------------
    methane_level          % by volume (% vol)
    carbon_monoxide        ppm
    dust_level             mg/m3  (respirable dust concentration)
    equipment_temperature  degrees Celsius
    vibration_level        mm/s RMS (vibration velocity)
    worker_count           whole number of people
    timestamp              ISO 8601, UTC, e.g. 2026-11-03T10:15:30Z

Press Ctrl+C to stop.
"""

import argparse
import json
import os
import random
import sys
import threading
import time
from datetime import datetime, timezone

try:
    import paho.mqtt.client as mqtt
except ImportError:
    print("ERROR: The 'paho-mqtt' package is not installed.")
    print("Install it with:  pip install paho-mqtt")
    sys.exit(1)


# --------------------------------------------------------------------------
# 1. Simulated plant layout (zones, areas, equipment)
# --------------------------------------------------------------------------
# Each area is paired with a piece of equipment that is "in" that area.
AREA_EQUIPMENT = [
    ("Coal Extraction Area", "Mining Drill"),
    ("Conveyor Area", "Conveyor Motor"),
    ("Underground Tunnel", "Ventilation Fan"),
]

# Normal operating ranges for the simulation (demo values only).
NORMAL = {
    "methane_level": (0.05, 0.50),          # % vol
    "carbon_monoxide": (1.0, 15.0),         # ppm
    "dust_level": (0.2, 1.0),               # mg/m3
    "equipment_temperature": (40.0, 62.0),  # deg C
    "vibration_level": (1.0, 3.5),          # mm/s RMS
}
# Warning-level ranges (should trigger the WARNING rules in n8n).
WARNING = {
    "methane_level": (1.0, 1.4),
    "carbon_monoxide": (36.0, 120.0),
    "dust_level": (1.6, 2.9),
    "equipment_temperature": (72.0, 88.0),
    "vibration_level": (4.6, 7.0),
}
# Critical-level ranges (should trigger the DANGER rules in n8n).
DANGER = {
    "methane_level": (1.5, 3.0),
    "carbon_monoxide": (200.0, 400.0),
    "dust_level": (3.0, 5.0),
    "equipment_temperature": (90.0, 115.0),
    "vibration_level": (7.2, 11.0),
}
DECIMALS = {
    "methane_level": 2,
    "carbon_monoxide": 1,
    "dust_level": 2,
    "equipment_temperature": 1,
    "vibration_level": 2,
}

UNITS = {
    "methane_level": "% vol",
    "carbon_monoxide": "ppm",
    "dust_level": "mg/m3",
    "equipment_temperature": "degC",
    "vibration_level": "mm/s RMS",
    "worker_count": "persons",
}


# --------------------------------------------------------------------------
# 2. Reading generator
# --------------------------------------------------------------------------
def pick(ranges, field):
    low, high = ranges[field]
    return round(random.uniform(low, high), DECIMALS[field])


def choose_level(scenario):
    """Decide whether this reading is normal / warning / danger."""
    if scenario in ("normal", "warning", "danger"):
        return scenario
    # 'random' mode: mostly normal, sometimes abnormal, so demos are interesting.
    roll = random.random()
    if roll < 0.75:
        return "normal"
    if roll < 0.93:
        return "warning"
    return "danger"


def generate_reading(zone, scenario, sequence):
    """Build one simulated reading as a Python dict."""
    level = choose_level(scenario)
    area, equipment = random.choice(AREA_EQUIPMENT)

    # Start with all-normal values...
    values = {f: pick(NORMAL, f) for f in NORMAL}

    # ...then push one or more fields into the abnormal range.
    fields = list(NORMAL.keys())
    if level == "warning":
        for f in random.sample(fields, k=random.choice([1, 1, 2])):
            values[f] = pick(WARNING, f)
    elif level == "danger":
        for f in random.sample(fields, k=random.choice([1, 2])):
            values[f] = pick(DANGER, f)

    # Equipment status loosely follows the situation.
    if level == "danger" and random.random() < 0.5:
        status = "STOPPED"
    elif level in ("warning", "danger"):
        status = "WARNING"
    else:
        status = "RUNNING"

    # Occasionally a normal reading shows a stopped machine (maintenance).
    if level == "normal" and random.random() < 0.03:
        status = "STOPPED"

    return {
        "mine_zone": zone,
        "mine_area": area,
        "methane_level": values["methane_level"],
        "carbon_monoxide": values["carbon_monoxide"],
        "dust_level": values["dust_level"],
        "equipment_name": equipment,
        "equipment_temperature": values["equipment_temperature"],
        "vibration_level": values["vibration_level"],
        "equipment_status": status,
        "worker_count": random.randint(0, 12),
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        # ---- metadata so nobody mistakes this for real data ----
        "units": UNITS,
        "simulated": True,
        "data_source": "SIMULATED - not real mine data",
        "sequence": sequence,
        "_scenario_hint": level,  # what the generator intended (for demo/testing only)
    }


def make_invalid_message(reading, sequence):
    """Return a deliberately bad payload (a string) to test n8n validation."""
    kind = sequence % 3
    if kind == 0:
        return '{"mine_zone": "Zone 1", "methane_level": '  # truncated / malformed JSON
    if kind == 1:
        bad = dict(reading)
        del bad["carbon_monoxide"]  # missing required field
        return json.dumps(bad)
    bad = dict(reading)
    bad["methane_level"] = "not-a-number"  # wrong type
    return json.dumps(bad)


# --------------------------------------------------------------------------
# 3. MQTT connection handling (works with paho-mqtt 1.x and 2.x)
# --------------------------------------------------------------------------
connected_event = threading.Event()


def on_connect(client, userdata, flags, rc, properties=None):
    failed = getattr(rc, "is_failure", None)
    if failed is None:
        failed = rc != 0
    if failed:
        print(f"[MQTT] Connection refused by broker (reason: {rc}). Will retry...")
        connected_event.clear()
    else:
        print("[MQTT] Connected to broker.")
        connected_event.set()


def on_disconnect(client, userdata, *args):
    connected_event.clear()
    print("[MQTT] Disconnected from broker. Automatic reconnection is running...")


def build_client(client_id, username, password):
    try:  # paho-mqtt 2.x
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    except AttributeError:  # paho-mqtt 1.x
        client = mqtt.Client(client_id=client_id)
    if username:
        client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    # Wait between 1 and 30 seconds between reconnection attempts.
    client.reconnect_delay_set(min_delay=1, max_delay=30)
    return client


# --------------------------------------------------------------------------
# 4. Main loop
# --------------------------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser(description="SIMULATED coal-mine sensor publisher (MQTT).")
    p.add_argument("--host", default=os.getenv("MQTT_HOST", "localhost"), help="MQTT broker host (default: localhost)")
    p.add_argument("--port", type=int, default=int(os.getenv("MQTT_PORT", "1883")), help="MQTT broker port (default: 1883)")
    p.add_argument("--topic", default=os.getenv("MQTT_TOPIC", "mine/zone1/sensors"), help="MQTT topic (default: mine/zone1/sensors)")
    p.add_argument("--zone", default="Zone 1", help='Value for mine_zone (default: "Zone 1")')
    p.add_argument("--interval", type=float, default=10.0,
                   help="Seconds between readings (default: 10). 3-5 is possible but may hit Groq rate limits.")
    p.add_argument("--scenario", choices=["random", "normal", "warning", "danger"], default="random",
                   help="random = mostly normal with occasional abnormal readings (default)")
    p.add_argument("--invalid-every", type=int, default=0,
                   help="Publish a deliberately invalid message every N messages (0 = never)")
    p.add_argument("--count", type=int, default=0, help="Stop after N messages (0 = run until Ctrl+C)")
    p.add_argument("--client-id", default="coal-mine-sensor-simulator")
    p.add_argument("--username", default=os.getenv("MQTT_USERNAME"))
    p.add_argument("--password", default=os.getenv("MQTT_PASSWORD"))
    p.add_argument("--seed", type=int, default=None, help="Random seed for repeatable demos")
    return p.parse_args()


def main():
    args = parse_args()
    if args.seed is not None:
        random.seed(args.seed)
    if args.interval <= 0:
        print("ERROR: --interval must be greater than 0.")
        return 2

    print("=" * 70)
    print(" SIMULATED SENSOR DATA - NOT FROM A REAL MINE")
    print(f" Broker : {args.host}:{args.port}")
    print(f" Topic  : {args.topic}")
    print(f" Every  : {args.interval} s   Scenario: {args.scenario}")
    print(" Press Ctrl+C to stop.")
    print("=" * 70)

    client = build_client(args.client_id, args.username, args.password)

    # connect_async + loop_start lets paho keep retrying in the background,
    # even if the broker is not running yet when this script starts.
    try:
        client.connect_async(args.host, args.port, keepalive=30)
    except Exception as exc:  # e.g. bad hostname
        print(f"[ERROR] Could not start connection: {exc}")
        return 1
    client.loop_start()

    sequence = 0
    try:
        while args.count == 0 or sequence < args.count:
            if not connected_event.wait(timeout=2):
                print(f"[WAIT] Not connected to {args.host}:{args.port} yet. "
                      "Is the Mosquitto service running? Retrying...")
                continue

            sequence += 1
            reading = generate_reading(args.zone, args.scenario, sequence)

            if args.invalid_every and sequence % args.invalid_every == 0:
                payload = make_invalid_message(reading, sequence)
                label = "INVALID (deliberate test message)"
            else:
                payload = json.dumps(reading)
                label = f"intended: {reading['_scenario_hint'].upper()}"

            try:
                info = client.publish(args.topic, payload, qos=1)
                info.wait_for_publish(timeout=5)
                if info.rc != mqtt.MQTT_ERR_SUCCESS or not info.is_published():
                    print(f"[ERROR] Publish #{sequence} failed or timed out (rc={info.rc}).")
                else:
                    print(f"[PUBLISHED #{sequence}] {label}\n  topic={args.topic}\n  {payload}\n")
            except (ValueError, RuntimeError) as exc:
                print(f"[ERROR] Publish #{sequence} raised an error: {exc}")

            time.sleep(args.interval)

    except KeyboardInterrupt:
        print("\n[STOP] Ctrl+C received. Shutting down...")
    finally:
        client.loop_stop()
        try:
            client.disconnect()
        except Exception:
            pass
        print("[STOP] Simulator stopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
